/*
 * Copyright (c) 2017, Hammurabi Mendes.
 * Licence: BSD 2-clause
 */
#ifndef SERVER_STATEMACHINE_H
#define SERVER_STATEMACHINE_H

int server_statemachine(int argc, char **argv);

#endif /* SERVER_STATEMACHINE_H */
