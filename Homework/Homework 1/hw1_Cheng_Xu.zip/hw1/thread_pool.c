#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<stdatomic.h>
#include"clients_common.h"
#include"thread_pool.h"

int queue_size = 0;
atomic_int finish = 0;

pthread_mutex_t queue_lock;
pthread_cond_t queue_not_empty;

pthread_t* consumers;

struct request *head = NULL;
struct request *tail = NULL;
struct request *current;

void put_request(struct client *client){
    
    pthread_mutex_lock(&queue_lock);
    struct request* request = (struct request*) malloc(sizeof(struct request*));
    request->client = client;
    if(head == NULL){
        head = request;
        head->next = NULL;
        tail = request;
    }
    else{
        current = head;
        while(current != NULL){
            current = current->next;
        }
        current = request;
        current->next = NULL;
        tail = request;
    }
    pthread_cond_signal(&queue_not_empty);
    pthread_mutex_unlock(&queue_lock);
}

struct request* get_request(void){
    struct request *temp;
    pthread_mutex_lock(&queue_lock);
    while(tail == NULL){
        pthread_cond_wait(&queue_not_empty, &queue_lock);
    }
    temp = tail;
    pthread_mutex_unlock(&queue_lock);
    return temp;
}

void *producer(void * data) {

	while(1) {
		sleep(1);
	}

	return NULL;
}

void *consumer(void * data) {
    while(!finish){
        struct request *request;

        while((request = get_request())) {
            struct client* client = request->client;
            pthread_mutex_lock(&queue_lock);
            current = head;
            while(current->next != NULL){
                current = current->next;
                if(current->next->next == NULL){
                    tail = current;
                }
            }
            current = NULL;
            pthread_mutex_unlock(&queue_lock);
            if(read_request(client)) {
                if(write_reply(client)){
                    client->status = STATUS_OK;
                    finish_client(client);
                }
            }

            if(client->status == STATUS_OK) {
                atomic_store(&operations_completed, operations_completed + 1);
            }

        }
    }
	return NULL;
}

int start_threads(){
    // Initialize the mutex
	pthread_mutex_init(&queue_lock, NULL);

    // Initialize the condition variable
	pthread_cond_init(&queue_not_empty, NULL);


    consumers = (pthread_t*) malloc(NUM_THREADS * sizeof(pthread_t));
    for(int i = 0; i < NUM_THREADS; i++){
        pthread_t consumerID;
        // Initialize threads
        pthread_attr_t config;

        pthread_attr_init(&config);
        pthread_attr_setdetachstate(&config, PTHREAD_CREATE_JOINABLE);
        pthread_create(&consumerID, &config, consumer, NULL);
        consumers[i] = consumerID;
    }

    return EXIT_SUCCESS;
}

int finish_threads(){
    finish = 1;

    pthread_cond_broadcast(&queue_not_empty);
    for(int i = 0; i < NUM_THREADS; i++){
        pthread_join(consumers[i], NULL);
    }
    atomic_store(&finish, 1);
    free(consumers);

    return EXIT_SUCCESS;
}
