/*
 * Copyright (c) 2017, Hammurabi Mendes.
 * Licence: BSD 2-clause
 */
#ifndef SERVER_FORK_H
#define SERVER_FORK_H

int server_fork(int argc, char **argv);

#endif /* SERVER_FORK_H */
