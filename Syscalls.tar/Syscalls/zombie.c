#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(int argc, char **argv) {
	int childID;

	childID = fork();

	if(childID == 0) {
		printf("I'm the child process, and my PID is %d\n", getpid());

		return EXIT_SUCCESS;
	}
	else {
		printf("I'm the parent process, and the child has ID %d\n", childID);

		sleep(10);
	}

	return EXIT_SUCCESS;
}
