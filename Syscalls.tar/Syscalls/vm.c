// If it doesn't work, your OS does address space layour randomization.

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

// Example comes from the book

int variable = 10;

int main(int argc, char **argv) {
	variable += 1;

	sleep(10);
	printf("value of variable = %d\n", variable);
	printf("location of variable = %p\n", &variable);

	return EXIT_SUCCESS;
}
