#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

#define BUFFER_LENGTH

int main(int argc, char **argv) {
    struct timeval time;

    if(gettimeofday(&time, NULL) == -1) {
        return EXIT_FAILURE;
    }

    struct tm *time_parsed = localtime(&(time.tv_sec));

    char time_string[128];

    strftime(time_string, 128, "Current date and time: %m-%d-%Y, %T\n", time_parsed);

    printf("%s", time_string);

    return 0;
}
