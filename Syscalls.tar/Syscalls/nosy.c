#include<stdio.h>
#include<stdlib.h>

int main(int argc, char **argv) {
	char *pointer1 = "David Bowie";
	char *pointer2 = (char *) 0x1a1a1a1a;

	printf("Who's singing first? %s\n", pointer1);
	fflush(stdout); // Try removing the flushes
	printf("Who's singing then? %s\n", pointer2);
	fflush(stdout); // Try removing the flushes

	return EXIT_SUCCESS;
}
