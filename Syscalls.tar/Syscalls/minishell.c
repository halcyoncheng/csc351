#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/wait.h>

#define COMMAND_LENGTH 128
#define ARGUMENT_LENGTH 16

int main(int argc, char **argv) {
	int variable = 10;
	int childID = 0;

	while(1) {
		char command[COMMAND_LENGTH];

		printf("MiniShell$> ");
		fgets(command, COMMAND_LENGTH, stdin);

		// Remove trailing newline character
		command[strlen(command) - 1] = '\0';

		if(strcmp(command, "exit") == 0) {
			return EXIT_SUCCESS;
		}

		char *arguments[ARGUMENT_LENGTH];

		char *tokens = command;
		char *token;
		int i;

		for(i = 0; i < ARGUMENT_LENGTH; i++) {
			token = strsep(&tokens, " ");

			if(!token) {
				break;
			}

			arguments[i] = token;
		}

		arguments[i] = NULL;

		childID = fork();

		if(childID == 0) {
			// I'm the child, I'll launch the program
			if(execvp(arguments[0], arguments) == -1) {
				perror("Error executing process");
			}

			// If we're here, exec failed
			return EXIT_FAILURE;
		}
		else {
			// I'm the parent, I'll wait for the child to die

			pid_t returnedChild;
			int returnStatus;

			do {
				returnedChild = wait(&returnStatus);
			} while(!WIFEXITED(returnStatus));

			printf("Process with PID = %d has finished\n", returnedChild);
		}
	}

	return EXIT_SUCCESS;
}
